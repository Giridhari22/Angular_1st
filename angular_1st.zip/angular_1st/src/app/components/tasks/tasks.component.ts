import { Component,Input , Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-tasks',
  // we have to use this selector name to show this component on app.comoponents.html
  templateUrl: './tasks.component.html',
  styleUrls: ['./tasks.component.scss']
})
export class TasksComponent {
  @Input() task!: string;
  @Output() taskDeleted = new EventEmitter<void>();

  onDeleteClick = () => {
    this.taskDeleted.emit();
  }

}