import { Component, OnInit } from '@angular/core';
import { MessageService } from './services/message.service';
import { FormArray, NgForm } from '@angular/forms';
import { FormBuilder , FormGroup , Validators } from '@angular/forms';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss'],
  providers: [MessageService],
})
export class AppComponent {
  // this below 1st line is only used when we have to implement OnInit
  // export class AppComponent implements OnInit{
  // 1.// // these all are built-in directive

  // title:string = 'angular_1st';
  // myBtn:string = "my Button";
  // counter: number  = 0;

  // // atrr binding
  // isDisabled: boolean = true;
  // angularImage : string = "../favicon.ico"

  // // style binding
  // bgColor :string = "Green";
  // titleColor:string ="white";
  // description :string = 'font-size:30px; color:lightBlue';

  // // class binding
  // redText: boolean= true;

  // // event binding
  // incrementCounter(){
  //   this.counter ++;
  // }

  // // two way binding - means whenever there is a variableand the data of that variable
  // // will show onhtml page (its normal ) but when the data is changed from html page , then there is also chnage in that variable with updated value
  // inputText: string = 'Initial Value';

  // // ngClass
  // message :string = ' this is the dangerous message ever 404';
  // classes : string = ' danger text-size'

  // // ngStyle
  // selectedColor : String ='violet';

  // //2. the structure directive - consists of three type
  // // conditional(if-else) , loop , switch statement
  // title: string = 'structure directive';
  // isLoggedIn: boolean = true;
  // username: string = "Giridhari"

  // // for loops
  // names: string[] = ["giri", 'juvaid', "nilesh", 'tulsi']
  // // switch statement
  // grade: string = 'B';

  //3. pipes - it is used to modify vallue of html through interpulation, we dont have to modify content in  component.ts ... we will directly chnage data
  // wheter it is interger or string or anything
  // title="pipes";
  // currency :number =1.3465;
  // today :number = Date.now();

  //   // 4.services
  //   messages : string[] =[];
  //   posts : any[] =[]
  // // MessageService- comes from above  provider
  //   constructor(private messageService:MessageService){

  //     console.log(this.messageService.getMessages())
  //   }
  //   title = '4.ServicesDi';

  //   // this is used to either pass above data or to integrate and call api by default
  //   ngOnInit() {
  //     this.messages = this.messageService.getMessages();

  //     this.messageService.getPosts().subscribe(
  //       (response:any) =>{
  //         this.posts = response.users
  //         console.log(this.posts)
  //       },
  //       (error)=>{
  //         console.error(error)
  //       }
  //     )
  //   }

  // // Template Driven form
  // user :{name:string,email:string } = {
  // name:'',
  // email:'',
  // }

  // submitForm( form:NgForm){
  //   if(form.valid){
  //     console.log(form.value, this.user);
  //   }
  // }

  // validateEmail():boolean{
  //   const emailRegex =  /^(([^<>()[\]\.,;:\s@\"]+(\.[^<>()[\]\.,;:\s@\"]+)*)|(\".+\"))@(([^<>()[\]\.,;:\s@\"]+\.)+[^<>()[\]\.,;:\s@\"]{2,})$/i;
  //   return emailRegex.test(this.user.email);
  // }

  userForm!: FormGroup;
  // FormBuilder, Validators and other helpers are default methods
  constructor(private formBuilder: FormBuilder) {
    this.userForm = this.formBuilder.group({
      name: ['', Validators.required],
      email: [
        '',
        [
          Validators.required,
          Validators.pattern(
            /^(([^<>()[\]\.,;:\s@\"]+(\.[^<>()[\]\.,;:\s@\"]+)*)|(\".+\"))@(([^<>()[\]\.,;:\s@\"]+\.)+[^<>()[\]\.,;:\s@\"]{2,})$/i
          ),
        ],
      ],

      address: this.formBuilder.group({
        street: ['', Validators.required],
        city: ['', Validators.required],
      }),
      phoneNumbers: this.formBuilder.array([
        this.formBuilder.control('', [
          Validators.required,
          Validators.pattern(/^\d{10}$/),
        ]),
      ]),
    });
  }

  addPhoneNumbers() {
    this.phoneNumbers.push(
      this.formBuilder.control('', [
        Validators.required,
        Validators.pattern(/^\d{10}$/),
      ])
    );
  }

  removePhoneNumber(index: number) {
    this.phoneNumbers.removeAt(index);
  }

  get phoneNumbers() {
    return this.userForm.get('phoneNumbers') as FormArray;
  }
  submitForm() {
    if (this.userForm.valid) {
      console.log(this.userForm.value);
    }
  }
// taask component which is children component
  tasks: string[] = ['task1', 'task2'];

  deleteTask(task:string){
    this.tasks = this.tasks.filter((t)=>t !=task)
  }
}
